/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function formatDateFromMysql(str_mysql_date){
    try{
        var t=new Date(Date.parse(str_mysql_date));
        if(isNaN(t.getFullYear())){
            return "<span class='default_error'>invalid</span>";
        }
        var str="";
        if(t.getDate()<10){
            str="0"+t.getDate();
        }else{
            str=str+t.getDate();
        } 
        
        if(t.getMonth()<9){
            str=str+"/0"+(t.getMonth()+1);
        }else{
            str=str+"/"+(t.getMonth()+1);
        }

        var str=str+"/"+t.getFullYear();
       
        

        return str;
    }catch(e){
        return "<span class='default_error'>invalid</span>";
    }
}
function getDateFromMysql(str_mysql_date){
    try{
        var t=new Date(Date.parse(str_mysql_date));
        if(isNaN(t.getFullYear())){
            return "";
        }
        var str="";
        if(t.getDate()<10){
            str="0"+t.getDate();
        }else{
            str=str+t.getDate();
        } 
        
        if(t.getMonth()<9){
            str=str+"/0"+(t.getMonth()+1);
        }else{
            str=str+"/"+(t.getMonth()+1);
        }

        var str=str+"/"+t.getFullYear();
       
        

        return str;
    }catch(e){
        return "";
    }
}
function setDateInput(obj,str_mysql_date,defaultDate){
    
    /*if(defaultDate==null){
        defaultDate=new Date();
    }
    try{
        var t=new Date(Date.parse(str_mysql_date));
        if(isNaN(t.getFullYear())){
            t=defaultDate;
        }
    }catch(e){
        t=defaultDate;
        
    }
 
    var str=""+t.getFullYear();
    if(t.getMonth()<9){
        str=str+"-0"+(t.getMonth()+1);
    }else{
        str=str+"-"+(t.getMonth()+1);
    }

    if(t.getDate()<10){
        str=str+"-0"+t.getDate();
    }else{
        str=str+"-"+t.getDate();
    }
    obj.value=str;*/
    try{
        var t=new Date(Date.parse(str_mysql_date));
        
        var str=""+t.getFullYear();
        if(t.getMonth()<9){
            str=str+"-0"+(t.getMonth()+1);
        }else{
            str=str+"-"+(t.getMonth()+1);
        }

        if(t.getDate()<10){
            str=str+"-0"+t.getDate();
        }else{
            str=str+"-"+t.getDate();
        }
        obj.value=str;
    }catch(e){
        
    }
}

 function synchAjax(u){
    try{
        var obj=$.ajax(
                {url:u,
                 async:false
                 }
        );
        return $.parseJSON(obj.responseText);
    }catch(e){
        return {result:0,message:"error while sending request server"};
    }
}

function clearTable(obj,n){
    while(obj.rows.length>n){
        obj.deleteRow(obj.rows.length-1);
    }

}

function removeChar(str,ch){
    var rg=new RegExp(ch);
    while(rg.test(str)){
        str=str.replace(rg,'');
    }
    return str;

}

function validateName(name){
    var rg=new RegExp("[A-Za-z]");
    var rgNum=new RegExp("[0-9]");
    var rgW=new RegExp("\W");
    if(!rg.test(name)){
        return false;
    }
    if(rgNum.test(name) || rgW.test(name)){
        return false;
    }
    
    return true;
}

function validateGender(str){
    var r=new RegExp("M|F");
    if(r.test(str)){
        return true;
    }else{
        return false;
    }
    
}

function validateDate(d){
    var r=new RegExp("\d{4}-\d{2}-\d{2}");
    if(r.test(d)){
        return true;
    }else{
        return false;
    }
}

function validatePhone(str){
    var rg=new RegExp("[A-Za-z]");
    var rgNum=new RegExp("[0-9]");
    var rgW=new RegExp("\W");
    if(!rgNum.test(name)){
        return false;
    }
    if(rg.test(name) || rgW.test(name)){
        return false;
    }
    
    return true;
}
function clearSelect(obj,firstOption){
    while(obj.options.length>0){
        obj.options.remove(0);
    }
    if(firstOption){
        var objNewOption=document.createElement("OPTION");
        objNewOption.value="0";
        objNewOption.text="--select--";
        obj.options.add(objNewOption);
    }
}



function showError(msg){
    $("#divStatus").html(msg);
    $("#divStatus").className="default_error";
}

function showStatus(msg){
    $("#divStatus").html(msg);
    $("#divStatus").className="default_status";
}


