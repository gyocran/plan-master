<?php
/**
*author: Aelaf T Dafla
*date: 05/06/2008
*/
define("LOG_HOST","localhost");
define("LOG_DB","mydb");
define("LOG_USER2","root");
define("LOG_PWORD","root");
define("LOG_PATH","c:/my_data/websites/plan4/ext/log/log_error.txt");
?>
