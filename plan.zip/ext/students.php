<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
include_once("rep.php");
class students extends rep{
    function students(){
        //db::db();
        rep::rep();
        $this->er_code_prefix=ER_APPLICANTS;     //error prefix for this class is 23
        $this->src="payments";
    }

    function add_application_record($firstname,$lastname,$birthdate,$gender,$startDate,$endDate,$entryLevel,$currentLevel,$academicProgram,$attendanceType,
            $jss,$school,$community,$programarea,$scholarshipType,$grant,$amount){
        $strQuery="insert into student_applicant(`student_firstname`,`student_lastname`,`student_gender`,`student_dob`,`community_community_id`,
            `app_submission_year`,`app_amount`,`app_status`,`app_primary_school_id`,`app_junior_secondary_id`,`student_admitted_school_id`,
            `student_resident_programarea_id`) 
            values('$firstname','$lastname','$gender','$birthdate',$community,$startDate,300,2,0,$jss,$school,$programarea)";

        if(!$this->sql_query($strQuery)){
            return false;
        }
        $id=$this->get_insert_id();
        if($id==false){
            return false;
        }
        $strQuery="insert into sponsored_student(`student_firstname`,
            `student_lastname`, `student_applicant_student_applicant_id`, `community_community_id`, `student_resident_programarea_id`)
               values('$firstname','$lastname',$id,$community,$programarea)";

        if(!$this->sql_query($strQuery)){
            return false;
        }
       $id=$this->get_insert_id();
        if($id==false){
            return false;
        }

        $strQuery="insert into school_attendance(`start_date`,`end_date`,`entry_class`,`entry_level`,`attendance_type`,`program`,
            `current_class`,`schools_school_id`,`sponsored_student_sponsored_student_id`)
            values($startDate,$endDate,$entryLevel,$entryLevel,'$attendanceType','$academicProgram',$currentLevel,$school,$id)";


         if(!$this->sql_query($strQuery)){
            return false;
        }


        $strQuery="insert into scholarship_package(`start_date`,`end_date`, `status`, `annual_amount`,
           `scholarship_type`,`grant_package_grant_package_id`, `sponsored_student_sponsored_student_id`,
           `scholarship_type_scholarship_type`)
            values($startDate,$endDate,1,$amount,$scholarshipType,$grant,$id,$scholarshipType)";


        if(!$this->sql_query($strQuery)){
            return false;
        }

        return true;

    }

    function update_student_record($student_id,$community_id,$firstname,$lastname,$middlename,$birthdate,$gender,$telephone1,$telephone2){
            $row=$this->get_student_record($student_id);
            if(!$row){
                return false;
            }
            $str_middlename="student_middlename=null";
            if($middlename==false){
                $str_middlename="student_middlename='$middlename'";
            }
            $str_query="update sponsored_student set 
                            student_firstname='$firstname',
                            student_lastname='$lastname',
                            $str_middlename,
                            community_community_id=$community_id
                        where sponsored_student_id=$student_id"; 
            
            if(!$this->sql_query($str_query)){
                return false;
            }
            $str_query="update student_applicant set 
                            student_firstname='$firstname',
                            student_lastname='$lastname',
                            $str_middlename,
                            student_gender='$gender',
                            student_dob='$birthdate',
                            student_telephone_2='$telephone1',
                            student_telephone_1='$telephone2',
                            community_community_id=$community_id
                        where student_applicant_id={$row['student_applicant_student_applicant_id']}";
             
             if(!$this->sql_query($str_query)){
                return false;
            }
            
            return true;
    }
    
    function get_student_record($id){
        $strQuery="SELECT
            s.`sponsored_student_id`, s.`student_firstname`, s.`student_middlename`, s.`student_lastname`,
            s.`student_picture`, s.`student_grades`, s.`student_applicant_student_applicant_id`,
            s.`student_resident_programarea_id`, s.`community_community_id`, s.`group_id`,
            programarea_name, community, District,
            sa.`student_telephone_1`, sa.`student_telephone_2`, sa.`student_dob`, sa.`app_submission_year`,
            sa.`student_gender`
            FROM sponsored_student s
            left join student_applicant sa on s.student_applicant_student_applicant_id=sa.student_applicant_id
            LEFT JOIN programarea on s.student_resident_programarea_id=programarea.programarea_id
            left join community  on s.community_community_id=community.`community_id`
            left join districts on community_districts_DistrictID=districts.DistrictID where s.sponsored_student_id={$id}";

       if(!$this->sql_query($strQuery)){
            return false;
        }
        return $this->fetch();

     
    }
    
    function get_students_from_programarea($programarea_id,$year,$search_text=0, $page,$limit){
        $filter="1";
        
        if($programarea_id!=0 && $year==0){
            $filter="s.`student_resident_programarea_id`=$programarea_id";
        }elseif($programarea_id!=0 && $year!=0){
            $filter="s.`student_resident_programarea_id`=$programarea_id and sa.`app_submission_year`=$year";
        }elseif($programarea_id==0 && $year!=0){
            $filter="sa.`app_submission_year`=$year";
        }else{
             $filter="1";
        }
        
        if($search_text){
            $filter.=" and (s.`student_firstname` like '%$search_text%' or s.`student_lastname` like '%$search_text%')";
        }
        
        return $this->get_students($filter, $page, $limit);
    }
     
    
    function get_students_from_district($district_id,$year, $page,$limit){
        $filter="1";
        if($district_id!=0 && $year==0){
            $filter="s.`district_id`=$district_id";
        }elseif($programarea_id!=0 && $year!=0){
            $filter="s.`district_id`=$district_id and sa.`app_submission_year`=$year";
        }elseif($programarea_id==0 && $year!=0){
            $filter="sa.`app_submission_year`=$year";
        }else{
             $filter="1";
        }
        
        return $this->get_students($filter, $page, $limit);
    }
    
    function get_students_from_community($community_id,$year, $page,$limit){
        $filter="1";
        if($district_id!=0 && $year==0){
            $filter="s.`community_community_id`=$community_id";
        }elseif($programarea_id!=0 && $year!=0){
            $filter="s.`community_community_id`=$community_id and sa.`app_submission_year`=$year";
        }elseif($programarea_id==0 && $year!=0){
            $filter="sa.`app_submission_year`=$year";
        }else{
             $filter="1";
        }
        
        return $this->get_students($filter, $page, $limit);
    }
    
    function get_student_count($programarea_id,$year,$search_text=0){
        $filter="1";
       
        if($programarea_id!=0 && $year==0 ){
            $filter="s.`student_resident_programarea_id`=$programarea_id";
        }elseif($programarea_id!=0 && $year!=0){
            $filter="s.`student_resident_programarea_id`=$programarea_id and sa.`app_submission_year`=$year";
        }elseif($programarea_id==0 && $year!=0){
            $filter="sa.`app_submission_year`=$year";
        }else{
             $filter="1";
        }
        if($search_text){
            $filter.=" and (s.`student_firstname` like '%$search_text%' or s.`student_lastname` like '%$search_text%')";
        }
        $str_query="select count(*) as no_rec FROM sponsored_student s left join student_applicant sa 
                on s.student_applicant_student_applicant_id=sa.student_applicant_id where $filter";
        
        if(!$this->sql_query($str_query)){
            return false;
        }
        
        $row=$this->fetch();
        return $row['no_rec'];
    }
    
    function get_students($filter, $page=0,$limit=0){
        $str_limit_clause="";
        if($limit!=0){
            $offset=($page-1)*$limit;
            $str_limit_clause="limit $offset,$limit";
        }
        $strQuery="SELECT s.`sponsored_student_id`, s.`student_firstname`, s.`student_middlename`, 
            s.`student_lastname`, s.`student_picture`, s.`student_grades`,
            s.`student_applicant_student_applicant_id`, s.`student_resident_programarea_id`, 
            s.`community_community_id`, s.`group_id`, programarea_name,districts.DistrictID, community, District, 
            sa.`student_telephone_1`, sa.`student_telephone_2`, sa.`student_dob`, 
            sa.`app_submission_year`, sa.`student_gender`,sch.`school_name`,sa.`app_grant_id`, gp.`name`
            FROM sponsored_student s left join student_applicant sa 
                on s.student_applicant_student_applicant_id=sa.student_applicant_id 
            LEFT JOIN programarea 
                on s.student_resident_programarea_id=programarea.programarea_id 
           left join community 
                    on s.community_community_id=community.`community_id`
            left join districts 
                    on community_districts_DistrictID=districts.DistrictID
            left join school_attendance sat 
                    on s.`sponsored_student_id`=sat.`sponsored_student_sponsored_student_id`
            left join schools sch on sat.`schools_school_id`=sch.`school_id`
            left join grant_package g on 
                sa.`app_grant_id`=g.`grant_package_id` left join grant_package gp on sa.`app_grant_id`=gp.`grant_package_id`"
                
            . " where $filter "
            . " order by programarea_name, community, District"
            . " $str_limit_clause ";

        
       if(!$this->sql_query($strQuery)){
            return false;
        }
        
        return true;
     
    }
    
    function get_student_attendance($id){
        $strQuery="SELECT year(s.`start_date`) as start_date, year(s.`end_date`) as end_date,
        s.`entry_class`, s.`entry_level`, s.`attendance_type`,
        s.`program`, s.`current_class`, s.`schools_school_id`, s.`sponsored_student_sponsored_student_id`,
        schools.school_name
        FROM school_attendance s
        LEFT JOIN schools on s.schools_school_id=schools.school_id where s.`sponsored_student_sponsored_student_id`={$id}";


       if(!$this->sql_query($strQuery)){
            return false;
        }
        return true;
    }

    function get_student_scholarhsip_payment($id){
        $strQuery="SELECT s.scholarship_package_scholarship_package_id,s.`date`, s.`status`, s.`refund_amount`, s.`amount`, s.`memo`,
                s.`year`, s.`schools_school_id`,
                `sponsored_student_sponsored_student_id`, `school_name`
                FROM scholarship_payment s
                LEFT JOIN scholarship_package on s.scholarship_package_scholarship_package_id=scholarship_package.scholarship_package_id
                LEFT JOIN schools on s.schools_school_id=schools.school_id
                WHERE `sponsored_student_sponsored_student_id`={$id}";

        if(!$this->sql_query($strQuery)){
            return false;
        }
        return true;
    }

    function add_school_attendance($id,$start_date,$end_date,$program,$attendance_type,$entry_class,$entry_level,$current_class){
    }
    
    function get_scholarship_package($id){
        $str_query="SELECT s.`scholarship_package_id`, s.`start_date`, s.`end_date`, s.`status`, 
            s.`annual_amount`, s.`scholarship_type`, s.`grant_package_grant_package_id`, 
            s.`sponsored_student_sponsored_student_id`, s.`scholarship_type_scholarship_type`, 
            s.`group_id` FROM scholarship_package s where s.`sponsored_student_sponsored_student_id`=$id";
        
        if(!$this->sql_query($str_query)){
            return false;
        }
        return $this->fetch();
    }

    
    function add_to_payment_request($student_id,$payment_request_id){
        $str_query="select custom_payment_request($payment_request_id,$student_id,1) as r";

        if(!$this->sql_query($str_query)){
            return false;
        }
        
        $row=$this->fetch();
        return $row["r"];
        
    }

    
}
?>
