<?php
/**
*author: Aelaf T Dafla
*date: 05/06/2008
*/

// Database connection info

define("DB_HOST", 'localhost');
define("DB_NAME", 'plangh_user2');
define("DB_PORT", 3306);
define("DB_USER","root");
define("DB_PWORD","");

define("PDF_FOLDER","ext/pdf/");
define("LOG_PATH","ext/log_error.txt");
?>
