/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function getStudentAttendance(obj,id){
    var u="ext/ajax.php?cmd=9&id=" +id;
    var objResult=synchAjax(u);
    if(objResult.result==0){
        showError(objResult.message);
        return;
    }
    var objDiv=document.getElementById("divAttendance");
    closePopups();
    //objDiv.style.position="absolute";
    //objDiv.style.top=event.clientY+20;
    //objDiv.style.left=200;
    objDiv.style.display="block";
    
    
    clearTable(document.getElementById("tableAttendance"),1);
    if(objResult.attendance.length==0){
        document.getElementById("spanAttendanceNoRecord").innerHTML="register to school";
        document.getElementById("spanAttendanceNoRecord").style.visibility="visible";
        document.getElementById("spanAttendanceNoRecord").style.className="hotspot";
    }
    
    
    for(i=0;i<objResult.attendance.length;i++){
        var r=document.getElementById("tableAttendance").insertRow(-1);
        var c=r.insertCell(0);
        c.innerHTML=objResult.attendance[i].start_date;
        c=r.insertCell(1);
        c.innerHTML=objResult.attendance[i].end_date;
        c=r.insertCell(2);
        c.innerHTML=objResult.attendance[i].program;
        c=r.insertCell(3);
        c.innerHTML=objResult.attendance[i].attendance_type;
        c=r.insertCell(4);
        c.innerHTML=objResult.attendance[i].school_name;
    }
    showStatus("student school registration ");
    
    //currentIndex=index;
    currentStudentId=id;
    currentTableRow=obj.parentNode.parentNode;
    currentColor=currentTableRow.style.backgroundColor;
    currentTableRow.style.backgroundColor="yellow";
}


function showConfirmPopup(){
    divConfirmPopup.style.display="block";
}

function addToPayment(){
    pid=$("#requestId").val();
    if(pid==0){
        showStatus("select payment request");
        return;
    }
    var str="ids=";
    var count=0;
    $("[type='checkbox']").each(function(i){
        if($(this).prop('checked')){
            str=str+$(this).val() + ",";
            count++;
        }
    });
    if(count>0){
        str=str.substr(0,str.length-1);
        var u="ext/ajax.php?cmd=11&pid="+pid+"&"+str;
        objResult=synchAjax(str);
        if(objResult.result==0){
            showStatus(objResult.message);
            return;
        }
    }else{
        showError("select students");
    }
    /*for(i=0;i<ids.length;i++){
        if(ids[i].checked){
            str=str+ids.value;
        }
    }*/
}

function addToPaymentSingle(){
    if(currentStudentId==0){
        return;
    }
    pid=$("#requestId").val();
    if(pid==0){
        showStatus("select payment request");
        return;
    }
    
    var u="ext/ajax.php?cmd=11&pid="+pid+"&ids="+currentStudentId;
    var objResult=synchAjax(u);
    if(objResult.result==0){
        showError(objResult.message);
        return;
    }
    var status=objResult.status[0].status;
    if(status==201){
        showStatus("already in request");
    }else if(status==202){
        showStatus("the scholarship for this student has been added to a request this year");
    }else if(status==200){
        showStatus("added to selected request");
    }else if(status<0){
        showStatus("error while adding to request");
    }

    var u="ext/ajax.php?cmd=12&id=" +currentStudentId;
    var objResult=synchAjax(u);
    if(objResult.result==0){
        showError(objResult.message);
        return;
    }
    var objDiv=document.getElementById("divPayment");
    closePopups();

    objDiv.style.display="block";
    
    
    clearTable(document.getElementById("tablePayment"),1);
    
   
    for(i=0;i<objResult.payments.length;i++){
        var r=document.getElementById("tablePayment").insertRow(-1);
        var c=r.insertCell(0);
        c.innerHTML=formatDateFromMysql(objResult.payments[i].date);
        c=r.insertCell(1);
        c.innerHTML=objResult.payments[i].status;
        c=r.insertCell(2);
        c.innerHTML=objResult.payments[i].amount;
        c=r.insertCell(3);
        c.innerHTML=objResult.payments[i].school_name;
    }
}

function getStudentPayment(obj,id){
    var u="ext/ajax.php?cmd=12&id=" +id;
    var objResult=synchAjax(u);
    if(objResult.result==0){
        showError(objResult.message);
        return;
    }
    var objDiv=document.getElementById("divPayment");
    closePopups();

    objDiv.style.display="block";
    
    
    clearTable(document.getElementById("tablePayment"),1);
    
   
    for(i=0;i<objResult.payments.length;i++){
        var r=document.getElementById("tablePayment").insertRow(-1);
        var c=r.insertCell(0);
        c.innerHTML=formatDateFromMysql(objResult.payments[i].date);
        c=r.insertCell(1);
        c.innerHTML=objResult.payments[i].status;
        c=r.insertCell(2);
        c.innerHTML=objResult.payments[i].amount;
        c=r.insertCell(3);
        c.innerHTML=objResult.payments[i].school_name;
    }
    showStatus("student payments ");
    
    //currentIndex=index;
    currentStudentId=id;
    currentTableRow=obj.parentNode.parentNode;
    currentColor=currentTableRow.style.backgroundColor;
    currentTableRow.style.backgroundColor="yellow";
}