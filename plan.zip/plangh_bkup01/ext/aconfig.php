<?php
/**
*author: Aelaf T Dafla
*date: 05/06/2008
*/

// Database connection info

define("DB_HOST", 'localhost');
define("DB_NAME", 'plangh_user');
define("DB_PORT", 3306);
define("DB_USER","plangh");
define("DB_PWORD","BSRWR8Z3@xBO");

define("PDF_FOLDER","ext/pdf/");
define("LOG_PATH","ext/log_error.txt");
?>
