<?php
	//create variable for root
	include "cconfig.php";

	include $custom_include_root.'payment_request_config.php';
	
?><?php
/*
	file ewcfg7.php
	include "./custom/init.php";

	file global_config_file:
	<?php //customization-kgosafomaafo: including header for all includes
	include "./custom/init.php";
	?>
	
	function SetupListOptions()
	{
		function SetupListOptions()
		//customization-kgosafomaafo
		//customization-start
		global $custom_include_root;
		include $custom_include_root.'payment_request_row_init.php';
		//customization-end
	}
	function RenderListOptions()
	{
		//customization-kgosafomaafo
		//customization-start
		global $custom_include_root;
		include $custom_include_root.'payment_request_row_use.php';
		//customization-end
	}
*/
?>