<?php
	//create variable for root
	$custom_include_root = "custom//";
	$cusom_application_name = 'PlanGhana';
?>