<?php
// "show"
		$this->ListOptions->Add("show");
		$item =& $this->ListOptions->Items["show"];
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = TRUE;
		$item->OnLeft = FALSE;

?>